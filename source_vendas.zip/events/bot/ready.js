const {} = require("discord.js");


module.exports = {
    name:"ready",
    run:async(client) => {

        console.log(`🤖 | Fui ligado em ${client.user.username}! 🤖`);

    }
} 