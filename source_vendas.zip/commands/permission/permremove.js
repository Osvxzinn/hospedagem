const { ApplicationCommandType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ApplicationCommandOptionType } = require("discord.js");
const {bot,carrinho,db,logs,pn,rd,vnd, dono, token , personalizar, perm} = require("../../database/index");
const owner = require("../../dono.json"); 
const fs = require('fs');

module.exports = {
    name:"permremove",
    description:"[🛠|💰 Vendas Moderação] Remover permissão a um usúario para gerenciar o sistema de vendas",
    type: ApplicationCommandType.ChatInput,
    options:[
        {
            name:"user",
            description:"Mencione o usuário que queira remover a permissão.",
            type: ApplicationCommandOptionType.User,
            required:true
        }
    ],
    run: async(client,interaction) => {
    try {
        const user = interaction.options.getUser("user")

function readOwnerId() {
    try {
      const data = fs.readFileSync('dono.json', 'utf8');
      const ownerData = JSON.parse(data);
      return ownerData.ownerId;
    } catch (err) {
      console.error('Erro ao ler o arquivo dono.json:', err);
      return null;
    }
  }
  
  // Código que compara o ID do usuário com o ID do dono
  if (interaction.user.id !== readOwnerId()) return interaction.reply({ content: "🔍 | Somente o dono do bot pode usar esse comando!", ephemeral: true });

    if(!await perm.get(`${user.id}`)) return interaction.reply({content:`🔍 | Esse Membro não tem permissão!`, ephemeral:true});
    await perm.delete(`${user.id}`);
    await interaction.reply({
        embeds:[
            new EmbedBuilder()
            .setDescription(`✅ | Foi Removida permissão para o membro ${user} com sucesso.`)
            .setColor("Green")
        ],
        ephemeral:true,
    });
    } catch {
        interaction.channel.send({content:`Ocorreu um erro, tente novamente`, ephemeral:true});
    }

}}
